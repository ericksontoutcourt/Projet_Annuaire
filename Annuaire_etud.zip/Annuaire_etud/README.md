    
# Connexion à MySQL en PHP avec PDO

Créer d'une application de base de données avec une connexion à MySQL en PHP


## Déroulement

- Installer la base de données et créer une table
- ajouter des employés
- Afficher la liste des employés
- Afficher la liste des employés filtrer 
- Supprimer des employés
- Modifier la fiche d'un employé